# TeachBayes, Version 1.03
Functions to Help Communicate Bayesian Inference

This package provides functions to accompany the text Probability and Bayesian Analysis by Jim Albert and Monika Hu.  There are functions to work with random
spinners, Bayes' rule, and inference for a normal mean and a binomial proportion.
