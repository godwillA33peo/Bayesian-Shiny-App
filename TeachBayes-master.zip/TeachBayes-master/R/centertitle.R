centertitle <- function(Color = "blue"){
  theme(plot.title = element_text(colour = Color, size = 18,
                    hjust = 0.5, vjust = 0.8, angle = 0))
}
