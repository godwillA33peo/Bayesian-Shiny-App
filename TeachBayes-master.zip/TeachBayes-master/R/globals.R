utils::globalVariables(c("Likelihood", "Prior",
                         "Product", "crcblue"))

